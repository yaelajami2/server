﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
namespace DAL
{
  public  class TripeDefinationDAL
    {
    //    public void PostPrice(int p)
    //    {
    //        using (Database5 ctx = new Database5())
    //        {
    //            foreach (Entities.Definition item in ctx.Definition)
    //            {
    //                if()
    //            }
    //        }    
    //    }
    }
}
