﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    [Flags]
    //public enum Season { Spring=1, Fall=2,Winter=4,Summer=8 };
    public enum Season { אביב = 1, סתיו = 2, חורף = 4,קיץ = 8 };
    [Flags]

   // public enum Audience { Children=1, Families=2, Groups=4, Couples =8}
    public enum Audience { ילדים = 1, משפחות = 2, קבוצות = 4, זוגות = 8 }
    public enum KindTrip { רטוב = 1, יבש = 2, מסלול = 3, טבע = 4 ,אטרקציה=5,פארקים=6,מוזיאון=7}
    public  class TripSite
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Code { get; set; }
        public string SiteName { get; set; }
        public string Description { get; set; }
        public Season Season { get; set; }
                                           //public Season[] Season { get; set; }
                                           //[NotMapped ]
                                           //public string  SeasonsSTR { get
                                           //    {
                                           //        StringBuilder sb=n
                                           //        string s = "";
                                           //        if (Season == null)
                                           //            return null;
                                           //        foreach (var item in Season)
                                           //        {
                                           //            s += item.ToString(); ;
                                           //        }
                                           //        return s;

        //     }
        //}
        public Audience Audience { get; set; }
        public string ActivityTime { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Area { get; set; }
        public string Settlement { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Contact { get; set; }
        public string Img { get; set; }
        public string Lengthoftrip { get; set; }
        public KindTrip KindTrip { get; set; }


    }
}
