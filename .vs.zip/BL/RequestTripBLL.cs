﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
   public class RequestTripBLL
    {
        public static void Delete(Entities.RequestTrip rt)
        {
            DAL.RequestTripDAL.Delete(rt);
        }
        
    }
}
