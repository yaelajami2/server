﻿using DAL;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Group : Form
    {
        public Group()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Group_Load(object sender, EventArgs e)
        {
            using (Database5 s = new Database5())
            {
                comboBox1.DataSource = s.Sites.ToList().Select(r => r.Area).Distinct().ToList();
                comboBox2.DataSource=s.Sites.ToList().Select(r => r.KindTrip).Distinct().ToList();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            using (Database5 ctx = new Database5())
            {
                label7.Visible = false;

                //try
                //{
                    ctx.RequestTrip.Add(new Entities.RequestTrip() { Area = comboBox1.Text,
                        KindTrip = (KindTrip)Enum.Parse(typeof(KindTrip), comboBox2.Text),
                        StartDate = dateTimePicker1.Value, EndDate = dateTimePicker2.Value,
                        Season = (Season)Enum.Parse(typeof(Season), comboBox3.Text),
                        NumberOfTravelers = (int)numericUpDown1.Value, UserId = 1});
                    ctx.SaveChanges();
            //}
                //catch
                //{
                //    label7.Visible = true;
                //}
            }
        }
    }
}
