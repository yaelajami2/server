﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            Listoftrip frm = new Listoftrip();
            frm.ShowDialog();
        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
            Contact frm = new Contact();
            frm.ShowDialog();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void ttttToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Contact frm = new Contact();
            frm.ShowDialog();
        }

        private void u7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application1 frm = new Application1();
            frm.ShowDialog();
        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Group frm = new Group();
            frm.ShowDialog();

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            OfferTrip frm = new OfferTrip();
            frm.ShowDialog();

        }

        private void toolStripLabel3_Click_1(object sender, EventArgs e)
        {
            Login frm = new Login();
            frm.ShowDialog();
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            OfferTrip frm = new OfferTrip();
            frm.ShowDialog();
        }
    }
}
