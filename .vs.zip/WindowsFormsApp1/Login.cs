﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
      
            try
            {
               


                using (Database5 ctx = new Database5())
                {
                    ctx.User.Add(new Entities.User() { FirstName = textBox1.Text, Mail = textBox2.Text, Phone = textBox3.Text });
                    ctx.SaveChanges();
                }
            }
            catch
            {
                string s = textBox3.Text,n = textBox1.Text;
                if(s.Length!=9)
                {
                    label7.Text = "מספר צריך להיות מורכב מ-9 ספרות";
                    label7.Visible = true;

                }
                for (int i = 0; i < s.Length; i++)
                {
                    if(!char.IsDigit(s[i]))
                    {
                        label7.Text = "הקש ספרות";
                        label7.Visible = true;

                          
                    }

                }
                if (n.Length ==0)
                {
                    label5.Text = "הקש שם";
                    label5.Visible = true;

                }

                for (int i = 0; i < n.Length; i++)
                {
                    if (!char.IsLetter(n[i]))
                    {
                        label5.Text = "שם חייב להיות מורכב מאותיות";
                        label5.Visible = true;


                    }

                }


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
