﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Application1 : Form
    {
        public Application1()
        {
            InitializeComponent();
        }

        internal static void EnableVisualStyles()
        {
            throw new NotImplementedException();
        }

        internal static void SetCompatibleTextRenderingDefault(bool v)
        {
            throw new NotImplementedException();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            textBox1.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            richTextBox1.Visible = false;
            comboBox1.Visible = false;
            button1.Visible = false;
            textBox5.Visible = true;


        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
    }
}
