﻿using DAL;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            using (Database5 s = new Database5())
            {


                comboBox3.DataSource = s.Sites.ToList().Select(r => r.Area).Distinct().ToList();


            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            TripSite t1 = new TripSite();
            //if ("Area" == comboBox3.Text && comboBox1.Text== "משתתפים" && comboBox2.Text == "עונה")
            //{
            //    label1.Visible = true;
            //    return;
            //}
            try
            {
                string s;
                if (radioButton1.Checked)
                {
                    s = "יום מלא";
                }
                else
                    if (radioButton2.Checked)
                    {
                        s ="חצי יום";
                    }

                

                   else
                  s = "טיול יותר מיום";
                    

                

                //label2.Text = groupBox1.CanSelect.ToString();
                RequestTrip t = new RequestTrip() { Area = comboBox3.Text, Season = (Season)Enum.Parse(typeof(Season), comboBox2.Text), Audience = (Audience)Enum.Parse(typeof(Audience), comboBox1.Text)};
                dataGridView2.DataSource = TripDAL.FindTrip(t).ToList();
            }


            catch
            {
                label1.Visible = true;
            }





        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_Leave(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {





        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

