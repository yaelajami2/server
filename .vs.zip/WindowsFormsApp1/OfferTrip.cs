﻿using DAL;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace WindowsFormsApp1
{
    public partial class OfferTrip : Form
    {
        DataGridViewTextBoxColumn n;
        public OfferTrip()
        {
            InitializeComponent();
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void OfferTrip_Load(object sender, EventArgs e)
        {
            using (Database5 ctx = new Database5())
            {
                List<Entities.RequestTrip> r = ctx.RequestTrip.Include(u=>u.User).ToList();

                dataGridView1.DataSource = r;
               n =new DataGridViewTextBoxColumn();

                

                DataGridViewButtonColumn col = new DataGridViewButtonColumn() { HeaderText = "הרשם"};
                 
                col.Text = "הצטרפות";
                

                col.UseColumnTextForButtonValue = true;
                dataGridView1.Columns.Add(col);
                dataGridView1.Columns.Add(n);

            }
        }

       

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dg = sender as DataGridView;
            if (dg.Columns[e.ColumnIndex ] is  DataGridViewButtonColumn    &&
                e.RowIndex>0)
            {
                Sum();
            }

        }

        private void Sum()
        {
            if (Convert.ToInt32(n.HeaderText )> 0)
                n.HeaderText = "uguyigt";

           //TotalCalculation frm = new TotalCalculation();
           // frm.ShowDialog();
        }
    }
}
